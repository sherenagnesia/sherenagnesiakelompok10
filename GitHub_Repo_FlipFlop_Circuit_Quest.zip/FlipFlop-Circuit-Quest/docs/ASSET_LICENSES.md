# Sumber dan Lisensi Aset

Spesifikasi mengizinkan aset berlisensi Free, buatan sendiri, atau AI generated. Isi kolom bertanda [isi].

| Kelompok aset | Sumber / alat | Lisensi | Keterangan |
|---|---|---|---|
| Gambar menu (btn_*, card*, judul_*, panel_*, logo, menu_bg) | [isi: buatan sendiri / AI, alat] | [isi] | Dibuat khusus untuk game (menurut README awal) |
| Sprite Sheren (walk, jump, dead, pose) | [isi] | [isi] | Spritesheet 24 frame |
| Objek level (floor, koin, listrik, petir, saklar, goal, gerbang, komponen) | [isi] | [isi] | |
| judul_toko, judul_gameover, panel_toko | Dibuat dengan skrip Python (Pillow) untuk proyek ini | Buatan sendiri | |
| foto dosen, asisten, pengembang | Foto pribadi masing-masing | Dipakai dengan izin yang bersangkutan | |
| Musik latar (bgm_menu, bgm_level1-3) | [isi] | [isi] | README awal menyebut musik asli bergaya chiptune |
| Efek suara (coin, jump, hit, switch, kuis, dll.) | [isi] | [isi] | |

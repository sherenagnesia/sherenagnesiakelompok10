# Laporan Progres Mingguan - Kelompok 10

Salin file ini untuk tiap minggu, beri nama `laporan-minggu-XX.md`.

| Item | Isi |
|---|---|
| Minggu ke | [isi] |
| Tanggal demo | [isi] |
| Disampaikan kepada | dosen / asisten: [isi] |
| Tempat | kelas default / lab game |

## Yang dikerjakan minggu ini
- [isi]

## Demonstrasi (apa yang diperlihatkan)
- [isi: fitur atau level yang didemokan]

## Kendala
- [isi]

## Rencana minggu depan
- [isi]

## Kartu Trello terkait
- [isi link kartu]

## Umpan balik dosen / asisten
- [isi setelah demo]

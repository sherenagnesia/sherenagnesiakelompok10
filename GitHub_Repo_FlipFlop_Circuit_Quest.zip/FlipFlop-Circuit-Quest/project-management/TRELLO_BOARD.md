# Papan Trello - Kelompok 10

## Cara menyiapkan (prosedur no. 1)
1. Buat board baru: "Flip-Flop Circuit Quest - Kelompok 10".
2. Buat 5 list: Backlog, To Do, Doing, Testing, Done.
3. Undang semua anggota, dosen (Harits Ar Rosyid), dan asisten (Arrayyan Daffa Assauqy, Albi Adwitiya Chandra) lewat Share, memakai email mereka.
4. Aktifkan Power-Up **GitHub** di menu board, lalu hubungkan ke repo proyek akhir agar kartu bisa ditautkan ke commit dan pull request.
5. Perbarui kartu rutin setiap minggu sebelum demo.

Tips: di Trello, tempel beberapa baris teks sekaligus saat membuat kartu agar tiap baris menjadi satu kartu.

## Kartu awal (tempel per list)

### Done
- Rancang GDD (draf lengkap)
- Buat level 1-3 dan materi SR, D, JK
- Tambah atribut: nyawa, energi, bit, XP
- Tambah item: kapasitor, resistor, LED, booster Turbo dan Perisai
- Buat Toko Workshop, Game Over, layar Misi Selesai
- Tambah cerita awal level dan scene Tentang
- Buat poster A4
- Buat instrumen uji (Functional Test, Alpha Test)

### To Do
- Uji game di GDevelop 5 (Preview) dan perbaiki error
- Jalankan Functional Test F01-F20
- Isi nama kelompok, topik umum, dan URL di GDD
- Catat sumber dan lisensi semua aset (docs/ASSET_LICENSES.md)
- Siapkan repo GitHub private dan undang semua anggota
- Hubungkan Trello dengan GitHub

### Backlog
- Alpha Test dengan 5-10 pemain
- Seimbangkan kesulitan dan ekonomi dari hasil Alpha Test
- Tambah checkpoint Level 3 (opsional)
- Ekspor HTML5 dan unggah ke webhost lab
- Uji build web di dua peramban
- Rekam video trailer (sekitar 5 menit) sesuai naskah GDD bagian 25
- Finalisasi GDD dan unduh PDF
- Susun draf HKI game, tanda tangan, submit
- Unggah semua luaran wajib ke tempat yang diminta dosen

### Checklist per minggu (kartu berulang)
- Siapkan demo kemajuan untuk dosen / asisten
- Perbarui kartu Trello
- Commit dan push ke GitHub
- Isi laporan mingguan

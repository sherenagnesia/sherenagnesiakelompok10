Letakkan hasil ekspor HTML5 GDevelop di folder ini (index.html, file js, aset).
